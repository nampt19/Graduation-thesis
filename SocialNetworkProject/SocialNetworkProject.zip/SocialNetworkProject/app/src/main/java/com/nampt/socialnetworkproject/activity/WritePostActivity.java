package com.nampt.socialnetworkproject.activity;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;
import com.nampt.socialnetworkproject.R;
import com.nampt.socialnetworkproject.adapter.rcvAdapter.PhotoWritePostAdapter;
import com.nampt.socialnetworkproject.util.FileUtil;


import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.List;

import gun0912.tedbottompicker.TedBottomPicker;
import gun0912.tedbottompicker.TedBottomSheetDialogFragment;


public class WritePostActivity extends AppCompatActivity {
    ImageView btnBack;
    TextView btnPost;
    EditText edtWritePost;
    RecyclerView rcvPost;
    PhotoWritePostAdapter photoAdapter;
    ImageView imgPhoto, imgVideo, imgPreviewVideo;
    VideoView videoWritePost;
    private static final int TYPE_REQUEST_VIDEO = 2, TYPE_REQUEST_PHOTO = 1, REQUEST_VIDEO_CODE = 53213;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write_post);
        addControl();
        addEvent();
    }

    private void addControl() {
        btnBack = findViewById(R.id.img_back_write_post_activity);
        btnPost = findViewById(R.id.btn_post);
        edtWritePost = findViewById(R.id.edt_write_post);
        rcvPost = findViewById(R.id.rcv_list_img_write_post);
        imgPhoto = findViewById(R.id.ic_image_write_post);
        imgVideo = findViewById(R.id.ic_video_write_post);
        videoWritePost = findViewById(R.id.video_write_post);
        imgPreviewVideo = findViewById(R.id.img_preview_video_write_post);


        //set adapter + recycle view
        photoAdapter = new PhotoWritePostAdapter(this);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        rcvPost.setLayoutManager(layoutManager);
        photoAdapter.setUriList(null);
        rcvPost.setAdapter(photoAdapter);

        edtWritePost.requestFocus();
    }


    private void addEvent() {
        imgPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestPermission(TYPE_REQUEST_PHOTO);
            }
        });
        imgVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestPermission(TYPE_REQUEST_VIDEO);
            }
        });
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btnPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }

    private void requestPermission(final int requestType) {
        PermissionListener permissionlistener = new PermissionListener() {
            @Override
            public void onPermissionGranted() {
                // request type 1 : Photo, type 2 : video
                if (requestType == TYPE_REQUEST_PHOTO) selectPhotoFromTedBottomPicker();
                else selectVideoFromGallery();
            }

            @Override
            public void onPermissionDenied(List<String> deniedPermissions) {
                Toast.makeText(WritePostActivity.this, "Quyền bị từ chối\n" + deniedPermissions.toString(), Toast.LENGTH_SHORT).show();
            }
        };
        TedPermission.with(this)
                .setPermissionListener(permissionlistener)
                .setDeniedMessage("Nếu bạn không cấp quyền, bạn sẽ không thể sử dụng dịch vụ\n\nLàm ơn vào mục [Cài đặt] > [Quyền]")
                .setPermissions(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA)
                .check();
    }

    private void selectVideoFromGallery() {
        photoAdapter.setUriList(null);
        Intent intent = new Intent();
        intent.setType("video/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Video"), REQUEST_VIDEO_CODE);
    }

    private void selectPhotoFromTedBottomPicker() {
        videoWritePost.stopPlayback();
        videoWritePost.setVisibility(View.GONE);
        imgPreviewVideo.setVisibility(View.GONE);
        TedBottomPicker.with(this)
                .setPeekHeight(1600)
                .showTitle(false)
                .setCompleteButtonText("Xong")
                .setEmptySelectionText("Chưa chọn ảnh nào")
                .setSelectMaxCount(4)
                .setSelectMaxCountErrorText("Không chọn quá 4 ảnh")
                .showMultiImage(new TedBottomSheetDialogFragment.OnMultiImageSelectedListener() {
                    @Override
                    public void onImagesSelected(List<Uri> uriList) {
                        // here is selected image uri list
                        if (uriList != null && !uriList.isEmpty()) {
                            photoAdapter.setUriList(uriList);
                        }
                    }
                });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_VIDEO_CODE && resultCode == RESULT_OK) {
            Uri selectedVideoUri = data.getData();
            if (selectedVideoUri == null) {
                return;
            }
            handleVideoLayout(selectedVideoUri);
        }
    }

    private void handleVideoLayout(Uri selectedVideoUri) {
        long fileSize = 0;
        try {
            fileSize = FileUtil.getSizeFileFrom(this, selectedVideoUri);
        } catch (IOException e) {
            e.printStackTrace();
        }
        Log.e("videoUri(159-writePost)", selectedVideoUri + " - Size file(Bytes): " + fileSize);
        if (fileSize > 30000000) {
            Toast.makeText(this, "File quá lớn(>30mb), vui lòng chọn lại", Toast.LENGTH_SHORT).show();
            return;
        }
        MediaController mediaController = new MediaController(this) {
            @Override
            public void show() {
                super.hide();
            }
        };
        // handle video UI, imagePreview UI
        videoWritePost.setVisibility(View.VISIBLE);
        imgPreviewVideo.setVisibility(View.VISIBLE);
        videoWritePost.setVideoURI(selectedVideoUri);
        videoWritePost.setMediaController(mediaController);
        mediaController.setAnchorView(videoWritePost);

        imgPreviewVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imgPreviewVideo.setVisibility(View.GONE);
                videoWritePost.start();
            }
        });
        videoWritePost.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                imgPreviewVideo.setVisibility(View.VISIBLE);
            }
        });
        videoWritePost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("click", "ok");
                if (videoWritePost.isPlaying()) {
                    imgPreviewVideo.setVisibility(View.VISIBLE);
                    videoWritePost.pause();
                } else {
                    imgPreviewVideo.setVisibility(View.GONE);
                    videoWritePost.start();
                }
            }
        });
    }
}