package com.nampt.socialnetworkproject.model;

import java.io.Serializable;

public class User implements Serializable {
    int id;
    String username;
    String urlAvartar;


    public User(int id, String username, String urlAvartar) {
        this.id = id;
        this.username = username;
        this.urlAvartar = urlAvartar;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUrlAvartar() {
        return urlAvartar;
    }

    public void setUrlAvartar(String urlAvartar) {
        this.urlAvartar = urlAvartar;
    }
}
