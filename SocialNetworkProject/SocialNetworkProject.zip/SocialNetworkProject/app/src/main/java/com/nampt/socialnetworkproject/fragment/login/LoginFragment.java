package com.nampt.socialnetworkproject.fragment.login;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import com.nampt.socialnetworkproject.activity.LoginActivity;
import com.nampt.socialnetworkproject.activity.MainActivity;
import com.nampt.socialnetworkproject.ILoginCallBacks;
import com.nampt.socialnetworkproject.R;

public class LoginFragment extends Fragment {
    EditText editTextPhoneLogin, editTextPasswordLogin;
    TextView txtOpenLayoutRegister;
    Button btnLogin;
    LoginActivity loginActivity;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Activities containing this fragment must implement interface: MainCallbacks
        if (!(getActivity() instanceof ILoginCallBacks)) {
            throw new IllegalStateException(" Activity must implement MainCallbacks");
        }
        loginActivity = (LoginActivity) getActivity(); // use this reference to invoke main callbacks
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        CardView layout_login = (CardView) inflater.inflate(R.layout.layout_login, null);

        addControl(layout_login);
        addEvent();

        return layout_login;
    }

    private void addControl(CardView layout_login) {
        txtOpenLayoutRegister = layout_login.findViewById(R.id.txtOpenLayoutRegister);
        btnLogin = layout_login.findViewById(R.id.btnLogin);
    }

    private void addEvent() {
        txtOpenLayoutRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginActivity.onMsgFromFragToMain("LOGIN_FRAGMENT");
            }
        });
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // save info user into sharePreference
                // direct to main Activity
                Intent intent = new Intent(loginActivity, MainActivity.class);
                startActivity(intent);
            }
        });
    }


}
