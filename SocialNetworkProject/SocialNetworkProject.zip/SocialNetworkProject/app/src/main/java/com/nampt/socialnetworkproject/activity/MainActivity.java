package com.nampt.socialnetworkproject.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.nampt.socialnetworkproject.adapter.ViewPagerAdapter;
import com.nampt.socialnetworkproject.R;

public class MainActivity extends AppCompatActivity {
    ViewPager viewPager;
    BottomNavigationView bottomNavigationView;
    Toolbar mainToolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addControl();
        addEvent();
    }

    private void addControl() {
        bottomNavigationView = findViewById(R.id.bottom_nav);
        viewPager = findViewById(R.id.viewPager_controller);
        mainToolbar = findViewById(R.id.main_toolbar);
        setUpToolBar();
        setUpBottomNav();
        setUpViewPager();
    }

    private void setUpToolBar() {

        mainToolbar.setTitle("Trang chủ");

    }

    private void setUpBottomNav() {
        // chuyển  item được chọn tương ứng vs fragment
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_home:
                        // get home_fragment
                        viewPager.setCurrentItem(0);
                        break;
                    case R.id.action_chat:
                        // get action_chat_fragment
                        viewPager.setCurrentItem(1);
                        break;
                    case R.id.action_group_chat:
                        // get group_chat_fragment
                        viewPager.setCurrentItem(2);
                        break;
                    case R.id.action_friend:
                        // get Friend_fragment
                        viewPager.setCurrentItem(3);
                        break;
                    case R.id.action_more:
                        // get More_fragment
                        viewPager.setCurrentItem(4);
                        break;

                }
                return true;
            }
        });
    }

    private void setUpViewPager() {
        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager(), FragmentStatePagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        viewPager.setAdapter(viewPagerAdapter);
        viewPager.setOffscreenPageLimit(4);
        // chuyển fragment tương ứng vs item được chọn
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                switch (position) {
                    case 0:
                        bottomNavigationView.getMenu().findItem(R.id.action_home).setChecked(true);
                        break;
                    case 1:
                        bottomNavigationView.getMenu().findItem(R.id.action_chat).setChecked(true);
                        break;
                    case 2:
                        bottomNavigationView.getMenu().findItem(R.id.action_group_chat).setChecked(true);
                        break;
                    case 3:
                        bottomNavigationView.getMenu().findItem(R.id.action_friend).setChecked(true);
                        break;
                    case 4:
                        bottomNavigationView.getMenu().findItem(R.id.action_more).setChecked(true);
                        break;
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    private void addEvent() {

    }


}