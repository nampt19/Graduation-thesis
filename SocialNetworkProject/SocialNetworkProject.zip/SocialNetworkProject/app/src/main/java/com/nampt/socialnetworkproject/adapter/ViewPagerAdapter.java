package com.nampt.socialnetworkproject.adapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.nampt.socialnetworkproject.fragment.main.ChatFragment;
import com.nampt.socialnetworkproject.fragment.main.FriendFragment;
import com.nampt.socialnetworkproject.fragment.main.GroupChatFragment;
import com.nampt.socialnetworkproject.fragment.main.HomeFragment;
import com.nampt.socialnetworkproject.fragment.main.MoreFragment;

public class ViewPagerAdapter extends FragmentStatePagerAdapter {
    public ViewPagerAdapter(@NonNull FragmentManager fm, int behavior) {
        super(fm, behavior);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 1:
                return new ChatFragment();
            case 2:
                return new GroupChatFragment();
            case 3:
                return new FriendFragment();
            case 4:
                return new MoreFragment();
            default:
                return new HomeFragment();

        }

    }

    @Override
    public int getCount() {
        return 5;
    }
}
