package com.nampt.socialnetworkproject.fragment.dialog;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.nampt.socialnetworkproject.R;
import com.nampt.socialnetworkproject.adapter.rcvAdapter.CommentAdapter;
import com.nampt.socialnetworkproject.model.Comment;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CommentBottomSheetDialogFragment extends BottomSheetDialogFragment {
    private static final String KEY_ID_POST = "ID_POST";
    private int idPost = 0;
    RecyclerView rcvComment;
    CommentAdapter commentAdapter;
    EditText edtComment;
    ImageButton btnSend;

    public static CommentBottomSheetDialogFragment instance(int idPost) {
        CommentBottomSheetDialogFragment commentDialogFragment = new CommentBottomSheetDialogFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(KEY_ID_POST, idPost);
        commentDialogFragment.setArguments(bundle);
        return commentDialogFragment;
    }

    @Override
    public int getTheme() {
        return R.style.AppBottomSheetDialogTheme;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundleReceiver = getArguments();
        if (bundleReceiver != null) {
            idPost = bundleReceiver.getInt(KEY_ID_POST);
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {

        BottomSheetDialog dialog = (BottomSheetDialog) super.onCreateDialog(savedInstanceState);
        View viewDialog = LayoutInflater.from(getContext()).inflate(R.layout.layout_bottom_sheet_comment_fragment, null);
        dialog.setContentView(viewDialog);
        addControl(viewDialog);
        addEvent(viewDialog);
        return dialog;
    }

    private void addEvent(final View viewDialog) {

    }

    private void addControl(View viewDialog) {
        rcvComment = viewDialog.findViewById(R.id.rcvComment);
        edtComment = viewDialog.findViewById(R.id.edt_write_comment);
        btnSend = viewDialog.findViewById(R.id.btn_send_comment);

        // set RecycleView + adapter
        LinearLayoutManager layoutManager = new LinearLayoutManager(viewDialog.getContext(), RecyclerView.VERTICAL, false);
        commentAdapter = new CommentAdapter(viewDialog.getContext());
        commentAdapter.setListComment(getListComment(idPost));
        rcvComment.setAdapter(commentAdapter);
        rcvComment.setLayoutManager(layoutManager);


    }

    private List<Comment> getListComment(int idPost) {
        // load comment by idPost !
        List<Comment> commentList = new ArrayList<>();
        commentList.add(new Comment("https://i.imgur.com/DvpvklR.png", "Phạm bằng", "ảnh đẹp quá bạn 1", new Date()));
        commentList.add(new Comment("https://i.imgur.com/DvpvklR.png", "Phạm bằng 2", "ảnh đẹp quá bạn 2!", new Date()));
        commentList.add(new Comment("https://i.imgur.com/DvpvklR.png", "Phạm bằng 3", "ảnh đẹp quá bạn 3!", new Date()));
        commentList.add(new Comment("https://i.imgur.com/DvpvklR.png", "Phạm bằng 4", "ảnh đẹp quá bạn 4!", new Date()));
        commentList.add(new Comment("https://i.imgur.com/DvpvklR.png", "Phạm bằng 5", "ảnh đẹp quá bạn 5!", new Date()));
        commentList.add(new Comment("https://i.imgur.com/DvpvklR.png", "Phạm bằng 6", "ảnh đẹp quá bạn 6!", new Date()));
        commentList.add(new Comment("https://i.imgur.com/Dvpvkl.png", "Phạm bằng 7", "ảnh đẹp quá bạn 7!", new Date()));
        commentList.add(new Comment("https://i.imgur.com/Dvpvkl.png", "Phạm bằng 8", "ảnh đẹp quá bạn 8!", new Date()));

        return commentList;
    }
}
