package com.nampt.socialnetworkproject.fragment.main;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.nampt.socialnetworkproject.R;
import com.nampt.socialnetworkproject.activity.MainActivity;
import com.nampt.socialnetworkproject.activity.WritePostActivity;
import com.nampt.socialnetworkproject.adapter.rcvAdapter.PostAdapter;
import com.nampt.socialnetworkproject.model.Post;
import com.nampt.socialnetworkproject.model.User;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HomeFragment extends Fragment {
    private RecyclerView rcvPost;
    private PostAdapter mPostAdapter;
    private MainActivity mActivity;
    TextView txtPost;
    Context mContext = null;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.e("Home1", "onCreate HomeFragment");
        mActivity = (MainActivity) getActivity();
        mContext = getContext();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View home = inflater.inflate(R.layout.fragment_home, container, false);
        addControl(home);
        addEvent();

        return home;
    }


    private void addEvent() {
            txtPost.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(mContext, WritePostActivity.class);
                    startActivity(intent);
                }
            });
    }

    private void addControl(View home) {
        rcvPost = home.findViewById(R.id.recycleViewPost);
        txtPost = home.findViewById(R.id.txt_post);

        mPostAdapter = new PostAdapter(mContext);
        LinearLayoutManager manager = new LinearLayoutManager(mContext,RecyclerView.VERTICAL,false);
        rcvPost.setLayoutManager(manager);
        mPostAdapter.setPostList(getListPost());
        rcvPost.setAdapter(mPostAdapter);
    }

    private List<Post> getListPost() {
        String urlImage1 = "https://i.imgur.com/rzIXcjq.jpg";
        String urlImage2 = "https://i.imgur.com/DvpvklR.png";
        String urlVideo2 = "https://www.w3schools.com/html/mov_bbb.mp4";
        String urlVideo1 = "https://www.w3schools.com/html/movie.mp4";
        List<Post> list = new ArrayList<>();
        User user1 = new User(1,"Nam Pham","https://i.imgur.com/DvpvklR.png");
        User user2 = new User(2,"Nam Pham2","https://i.imgur.com/rzIXcjq.jpg");
        Post post1 = new Post(user1,new Date(),"ok ban",urlImage1,urlImage2,urlImage1,urlImage2,urlVideo1,22,33);
        Post post2 = new Post(user2,new Date(),"ok ban2",urlImage1,urlImage1,urlImage1,urlImage2,urlVideo2,21,13);
        Post post3 = new Post(user2,new Date(),"ok ban3",urlImage1,urlImage1,urlImage1,urlImage2,urlVideo2,21,13);
        Post post4 = new Post(user2,new Date(),"ok ban4",urlImage1,urlImage1,urlImage1,urlImage2,urlVideo2,21,13);

        list.add(post1);
        list.add(post2);
        list.add(post3);
        list.add(post4);
        return list;
    }
}