package com.nampt.socialnetworkproject.adapter.rcvAdapter;

import android.app.Activity;
import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.nampt.socialnetworkproject.R;
import com.nampt.socialnetworkproject.fragment.dialog.CommentBottomSheetDialogFragment;
import com.nampt.socialnetworkproject.model.Post;

import java.util.List;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.ViewHolder> {
    private Context mConText;
    private List<Post> mPostList;
    MediaController mediaController;

    public PostAdapter(Context mConText) {
        this.mConText = mConText;
    }

    public void setPostList(List<Post> postList) {
        this.mPostList = postList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mConText);
        View postView = inflater.inflate(R.layout.item_post, parent, false);
        return new ViewHolder(postView);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        Post post = mPostList.get(position);
        if (post == null || post.getUser() == null) return;
        handleUserProfile(holder, post);
        handlePhotoAndVideoPost(holder, post);
        handleLike(holder, post);
        openCommentDialog(holder, post);
//        holder.container_img_post__1_3.setVisibility(View.GONE);
//        holder.container_img_post__2_4.setVisibility(View.GONE);
//     holder.container_video_post.setVisibility(View.GONE);

    }


    @Override
    public int getItemCount() {
        return mPostList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView imgUser;
        private TextView txtNameUser;
        private TextView timePost;
        private TextView txtContentPost;
        private View container_img_post__1_3;
        private View container_img_post__2_4;
        private View container_video_post;
        private ImageView imgPost1;
        private ImageView imgPost2;
        private ImageView imgPost3;
        private ImageView imgPost4;
        private VideoView videoPost;
        private ImageView imgPreviewVideo;

        private TextView totalLike;
        private TextView totalComment;
        private ImageView imgLike, imgComment;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgUser = itemView.findViewById(R.id.img_user_post);
            txtNameUser = itemView.findViewById(R.id.txt_name_user_post);
            timePost = itemView.findViewById(R.id.txt_time_post);
            txtContentPost = itemView.findViewById(R.id.txt_content_post);
            container_img_post__1_3 = itemView.findViewById(R.id.container_img_post__1_3);
            container_img_post__2_4 = itemView.findViewById(R.id.container_img_post_2_4);
            container_video_post = itemView.findViewById(R.id.container_video_post);
            imgPost1 = itemView.findViewById(R.id.img_post_1);
            imgPost2 = itemView.findViewById(R.id.img_post_2);
            imgPost3 = itemView.findViewById(R.id.img_post_3);
            imgPost4 = itemView.findViewById(R.id.img_post_4);
            videoPost = itemView.findViewById(R.id.video_post);
            imgPreviewVideo = itemView.findViewById(R.id.img_preview_video_post);

            totalLike = itemView.findViewById(R.id.txt_total_like_post);
            totalComment = itemView.findViewById(R.id.txt_total_comment_post);
            imgLike = itemView.findViewById(R.id.img_like_post);
            imgComment = itemView.findViewById(R.id.img_comment_post);
        }
    }

    private void handleUserProfile(ViewHolder holder, Post post) {
        Glide.with(mConText).load(post.getUser().getUrlAvartar()).placeholder(R.drawable.null_bk).into(holder.imgUser);
        holder.txtNameUser.setText(post.getUser().getUsername());
    }

    private void handlePhotoAndVideoPost(ViewHolder holder, Post post) {
        holder.timePost.setText(post.getTime() + "");
        holder.txtContentPost.setText(post.getContent());
        Glide.with(mConText).load(post.getUrlImage1()).placeholder(R.drawable.null_bk).into(holder.imgPost1);
        Glide.with(mConText).load(post.getUrlImage2()).placeholder(R.drawable.null_bk).into(holder.imgPost2);
        Glide.with(mConText).load(post.getUrlImage3()).placeholder(R.drawable.null_bk).into(holder.imgPost3);
        Glide.with(mConText).load(post.getUrlImage4()).placeholder(R.drawable.null_bk).into(holder.imgPost4);
        handleVideoPost(holder, post);
    }

    private void handleVideoPost(final ViewHolder holder, Post post) {
        mediaController = new MediaController(mConText) {
            @Override
            public void show() {
                super.hide();
            }

        };
        holder.videoPost.setVideoPath(post.getUrlVideo());
        holder.videoPost.setMediaController(mediaController);
        mediaController.setAnchorView(holder.videoPost);

        holder.imgPreviewVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.imgPreviewVideo.setVisibility(View.GONE);
                holder.videoPost.start();
            }
        });
        holder.videoPost.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(MediaPlayer mp, int what, int extra) {
                if (what == MediaPlayer.MEDIA_ERROR_UNKNOWN || what == MediaPlayer.MEDIA_ERROR_SERVER_DIED) {
                    Toast.makeText(mConText, "Lỗi mạng,không thể phát video !", Toast.LENGTH_SHORT).show();
                    return true;
                }
                return false;
            }
        });
        holder.videoPost.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                holder.imgPreviewVideo.setVisibility(View.VISIBLE);
            }
        });
        holder.videoPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("click", "ok");
                if (holder.videoPost.isPlaying()) {
                    holder.imgPreviewVideo.setVisibility(View.VISIBLE);
                    holder.videoPost.pause();
                } else {
                    holder.imgPreviewVideo.setVisibility(View.GONE);
                    holder.videoPost.start();
                }
            }
        });
    }

    private void handleLike(ViewHolder holder, Post post) {
        holder.totalLike.setText(post.getTotalLike() + "");
        holder.totalComment.setText(post.getTotalComment() + "");

        final ImageView imgLike = holder.imgLike;
        imgLike.setOnClickListener(new View.OnClickListener() {
            boolean isLike = true;

            @Override
            public void onClick(View v) {
                if (isLike) {
                    imgLike.setColorFilter(ContextCompat.getColor(mConText, R.color.colorBlueThin));
                    isLike = false;
                } else {
                    imgLike.setColorFilter(ContextCompat.getColor(mConText, R.color.colorGreyThin));
                    isLike = true;
                }
            }
        });
    }

    private void openCommentDialog(ViewHolder holder, Post post) {
        holder.imgComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CommentBottomSheetDialogFragment dialogFragment = CommentBottomSheetDialogFragment.instance(1);
                dialogFragment.show(((FragmentActivity) mConText).getSupportFragmentManager(),dialogFragment.getTag());
            }
        });
    }
}
