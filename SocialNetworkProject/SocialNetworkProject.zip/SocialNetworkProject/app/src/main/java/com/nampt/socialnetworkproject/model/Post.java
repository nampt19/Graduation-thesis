package com.nampt.socialnetworkproject.model;

import java.util.Date;

public class Post {
    private User user;
    private Date time;
    private String content;
    private String urlImage1;
    private String urlImage2;
    private String urlImage3;
    private String urlImage4;
    private String urlVideo;
    private int totalLike;
    private int totalComment;

    public User getUser() {
        return user;
    }

    public Post(User user, Date time, String content, String urlImage1, String urlImage2, String urlImage3, String urlImage4, String urlVideo, int totalLike, int totalComment) {
        this.user = user;
        this.time = time;
        this.content = content;
        this.urlImage1 = urlImage1;
        this.urlImage2 = urlImage2;
        this.urlImage3 = urlImage3;
        this.urlImage4 = urlImage4;
        this.urlVideo = urlVideo;
        this.totalLike = totalLike;
        this.totalComment = totalComment;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public String getUrlImage1() {
        return urlImage1;
    }

    public void setUrlImage1(String urlImage1) {
        this.urlImage1 = urlImage1;
    }

    public String getUrlImage2() {
        return urlImage2;
    }

    public void setUrlImage2(String urlImage2) {
        this.urlImage2 = urlImage2;
    }

    public String getUrlImage3() {
        return urlImage3;
    }

    public void setUrlImage3(String urlImage3) {
        this.urlImage3 = urlImage3;
    }

    public String getUrlImage4() {
        return urlImage4;
    }

    public void setUrlImage4(String urlImage4) {
        this.urlImage4 = urlImage4;
    }

    public String getUrlVideo() {
        return urlVideo;
    }

    public void setUrlVideo(String urlVideo) {
        this.urlVideo = urlVideo;
    }

    public int getTotalLike() {
        return totalLike;
    }

    public void setTotalLike(int totalLike) {
        this.totalLike = totalLike;
    }

    public int getTotalComment() {
        return totalComment;
    }

    public void setTotalComment(int totalComment) {
        this.totalComment = totalComment;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
