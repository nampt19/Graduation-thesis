package com.nampt.socialnetworkproject.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.nampt.socialnetworkproject.ILoginCallBacks;
import com.nampt.socialnetworkproject.fragment.login.LoginFragment;
import com.nampt.socialnetworkproject.R;
import com.nampt.socialnetworkproject.fragment.login.RegisterFragment;

public class LoginActivity extends AppCompatActivity implements ILoginCallBacks {

    Button btnLogin;
    FragmentTransaction ft;
    LoginFragment loginFragment;
    RegisterFragment registerFragment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        addControl();
        addEvent();
    }

    private void addControl() {
      //  getSupportActionBar().hide();
        btnLogin = findViewById(R.id.btnLogin);

        ft = getSupportFragmentManager().beginTransaction();
        loginFragment = new LoginFragment();
        ft.add(R.id.main_holder_login, loginFragment, "LOGIN_FRAGMENT");
        ft.commit();

    }

    private void addEvent() {

    }


    @Override
    public void onMsgFromFragToMain(String sender) {
        switch (sender){
            case "LOGIN_FRAGMENT":
                ft = getSupportFragmentManager().beginTransaction();
                registerFragment = new RegisterFragment();
                ft.add(R.id.main_holder_login, registerFragment, "REGISTER_FRAGMENT");
                ft.addToBackStack("REGISTER_FRAGMENT");
                ft.commit();
                break;
            case "REGISTER_FRAGMENT":
                if (getSupportFragmentManager() != null) {
                    getSupportFragmentManager().popBackStack();
                }

                break;
        }
    }


}