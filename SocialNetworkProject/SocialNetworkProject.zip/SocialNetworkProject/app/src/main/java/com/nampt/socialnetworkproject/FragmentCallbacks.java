package com.nampt.socialnetworkproject;

public interface FragmentCallbacks {
    public void onMsgFromFragToMain(String sender,String username,String password);
}
