package com.nampt.socialnetworkproject.fragment.login;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.nampt.socialnetworkproject.activity.LoginActivity;
import com.nampt.socialnetworkproject.ILoginCallBacks;
import com.nampt.socialnetworkproject.R;

public class RegisterFragment extends Fragment {
    LoginActivity loginActivity;
    TextView txtOpenLayoutLogin;
    EditText txtUsernameRegister, txtPhoneRegister, txtPasswordRegister, txtVerifyPasswordRegister;
    Button btnRegister;
    ProgressDialog progressDialog;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!(getActivity() instanceof ILoginCallBacks)) {
            throw new IllegalStateException(" Activity must implement MainCallbacks");
        }
        loginActivity = (LoginActivity) getActivity();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        CardView layout_register = (CardView) inflater.inflate(R.layout.layout_register, null);
        addControl(layout_register);
        addEvent();


        return layout_register;
    }

    private void addControl(View v) {
        txtOpenLayoutLogin = v.findViewById(R.id.txtOpenLayoutLogin);
        txtUsernameRegister = v.findViewById(R.id.txtUsernameRegister);
        txtPhoneRegister = v.findViewById(R.id.txtPhoneRegister);
        txtPasswordRegister = v.findViewById(R.id.txtPasswordRegister);
        txtVerifyPasswordRegister = v.findViewById(R.id.txtVerifyPasswordRegister);
        btnRegister = v.findViewById(R.id.btnRegister);
        progressDialog = new ProgressDialog(loginActivity, R.style.myLoadingDialogStyle);
    }

    private void addEvent() {
        txtOpenLayoutLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginActivity.onMsgFromFragToMain("REGISTER_FRAGMENT");
            }
        });
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.setMessage("Đang tải, vui lòng đợi !");
                progressDialog.show();
                final Handler handler = new Handler(Looper.getMainLooper());
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        //Do something after 100ms
                        progressDialog.dismiss();
                    }
                }, 2000);
        //        showMyAlertDialog(loginActivity);

            }
        });
    }

    private void showMyAlertDialog(LoginActivity loginActivity) {
        AlertDialog.Builder builder = new AlertDialog.Builder(loginActivity)
                .setTitle("Terminator")
                .setMessage("Are you sure that you want to quit?")
                .setIcon(R.drawable.ic_launcher_background)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {

                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                    }
                });
        AlertDialog dialog = builder.create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(ContextCompat.getColor(requireContext(), R.color.colorRed));
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(requireContext(), R.color.colorBlueThin));


    }


}
