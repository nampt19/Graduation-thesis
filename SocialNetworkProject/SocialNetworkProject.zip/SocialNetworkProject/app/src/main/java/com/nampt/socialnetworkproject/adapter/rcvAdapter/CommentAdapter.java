package com.nampt.socialnetworkproject.adapter.rcvAdapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.nampt.socialnetworkproject.R;
import com.nampt.socialnetworkproject.model.Comment;

import java.util.List;

public class CommentAdapter extends RecyclerView.Adapter<CommentAdapter.ViewHolder> {
    private Context mContext;
    private List<Comment> mListComment;

    public CommentAdapter(Context mContext) {
        this.mContext = mContext;
    }

    public void setListComment(List<Comment> mListComment) {
        this.mListComment = mListComment;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View itemCommentView = inflater.inflate(R.layout.item_comment, parent, false);
        return new ViewHolder(itemCommentView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Comment comment = mListComment.get(position);
        if (comment == null) return;
        Glide.with(mContext).load(comment.getUrlImageUser()).placeholder(R.drawable.unnamed).into(holder.urlImgUser);
        holder.txtUsername.setText(comment.getUsername());
        holder.txtContent.setText(comment.getContent());
        holder.txtTime.setText(comment.getTime().toString()); // parse date here !

    }

    @Override
    public int getItemCount() {
        if (mListComment == null || mListComment.isEmpty()) return 0;
        return mListComment.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView urlImgUser;
        private TextView txtUsername, txtContent, txtTime;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            urlImgUser = itemView.findViewById(R.id.url_img_username_comment);
            txtUsername = itemView.findViewById(R.id.txt_username_comment);
            txtContent = itemView.findViewById(R.id.txt_content_comment);
            txtTime = itemView.findViewById(R.id.txt_time_comment);
        }
    }
}
