package com.nampt.socialnetworkproject;

public interface ILoginCallBacks {
    public void onMsgFromFragToMain(String sender);

}
